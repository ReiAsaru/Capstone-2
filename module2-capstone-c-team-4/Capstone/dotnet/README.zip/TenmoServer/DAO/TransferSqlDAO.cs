﻿using Microsoft.EntityFrameworkCore.Internal;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using TenmoServer.Models;

namespace TenmoServer.DAO
{
    public class TransferSqlDAO : ITransferDAO
    {
        private string connectionString;

        private IAccountDAO Acct;

        public TransferSqlDAO(string databaseConnectionString)
        {
            connectionString = databaseConnectionString;
        }
        private Transfer GetTransferFromReader(SqlDataReader reader)
        {
            Transfer transfer = new Transfer()
            {
                Transfer_Id = Convert.ToInt32(reader["transfer_id"]),
                Transfer_Type_Id = Convert.ToInt32(reader["transfer_type_id"]),
                Transfer_Status_Id = Convert.ToInt32(reader["transfer_status_id"]),
                Account_From = Convert.ToInt32(reader["account_from"]),
                Account_To = Convert.ToInt32(reader["account_to"]),
                Amount = Convert.ToDecimal(reader["amount"]),
            };
            return transfer;
        }

        public bool CreateTransfer(Account fromAcct, Account toAcct, TransferDTO amt)
        {
            bool success = false;
            //set status for both to and from to pending (transfer_status_id = 1 sql)

            //    add amt to userIdTo
            //subtract amt from userIdFrom

            //Transfer returnTransfer = new Transfer();
            if (fromAcct.Balance < amt.Amount)
            {
                return false; //insufficient funds
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    // first UPDATE stmt does the subtraction of balance - amt of the sender
                    // second UPDATE stmt does the addition of balance + amt of the reciver

                    SqlCommand cmd = new SqlCommand(@"UPDATE accounts SET balance = balance - @amt WHERE user_id = @user_id; 
                                                    UPDATE accounts SET balance = balance + @amt WHERE user_id = @user_id_to; 
                                                    INSERT INTO [dbo].[transfers]
           ([transfer_type_id]
           ,[transfer_status_id]
           ,[account_from]
           ,[account_to]
           ,[amount])
     VALUES
           (2, 2, @user_id, @user_id_to, @amt) ", conn);
                    cmd.Parameters.AddWithValue("@user_id", fromAcct.User_Id);
                    cmd.Parameters.AddWithValue("@user_id_to", toAcct.User_Id);
                    cmd.Parameters.AddWithValue("@amt", amt.Amount);

                    int numberOfRowsEffected = cmd.ExecuteNonQuery();


                    if (numberOfRowsEffected > 0)
                    {

                        success = true;
                    }
                        

                }
            }
            catch (SqlException)
            {
                throw;
            }
            return success;
        }

        //if ok return status approved
        //else return status rejected



        public Transfer GetTransferById(int transfer_id)
        {
            Transfer returnTransfer = new Transfer();
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT transfer_id, transfer_type_id, " +
                                                    "transfer_status_id,account_from, account_to, amount " +
                                                    "FROM transfers " +
                                                    "WHERE transfer_id = transfer_id, conn");
                    cmd.Parameters.AddWithValue("@transfer_id", transfer_id);

                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        returnTransfer.Transfer_Id = Convert.ToInt32(reader["transfer_id"]);
                        returnTransfer.Transfer_Type_Id = Convert.ToInt32(reader["transfer_type_id"]);
                        returnTransfer.Transfer_Status_Id = Convert.ToInt32(reader["transfer_status_id"]);
                        returnTransfer.Account_From = Convert.ToInt32(reader["account_from"]);
                        returnTransfer.Account_To = Convert.ToInt32(reader["account_to"]);
                        returnTransfer.Amount = Convert.ToDecimal(reader["amount"]);
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }
            return returnTransfer;
        }

        public List<Transfer> GetTransferList(int userID)
        {
            List<Transfer> transferList = new List<Transfer>();
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(@"SELECT transfer_id, 
                                                    account_from, account_to, amount
                                                    FROM transfers 
                                                    WHERE account_from = @user_id or account_to = @user_id", conn);
                    cmd.Parameters.AddWithValue("@user_id", userID);

                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Transfer transfer = new Transfer();

                        transfer.Transfer_Id = Convert.ToInt32(reader["transfer_id"]);
                        transfer.Account_From = Convert.ToInt32(reader["account_from"]);
                        transfer.Account_To = Convert.ToInt32(reader["account_to"]);
                        transfer.Amount = Convert.ToDecimal(reader["amount"]);
                        transferList.Add(transfer);
                    }
                }
            }
            catch (SqlException)
            {
                throw;
            }

            return transferList;
        }

    }
}

